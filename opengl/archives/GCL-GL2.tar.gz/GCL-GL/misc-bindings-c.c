#include<stdio.h>
#include<sys/time.h>

extern void free (int);
extern int calloc (int, int);

/* Portable implementation of BSD Usleep routine */
int usleep(int n) {
 struct timeval value;
 if (n <= 0) return;
 value.tv_usec = n % 1000000;
 value.tv_sec = n / 1000000;
 (void) select(1, 0, 0, 0, &value);
}

int make_chara (int n) { return ((int)calloc(n,sizeof(char))); }
char chara_ref (int p, int i) { return (((char*)p)[i]); }
char chara_set (int p, int i, char v) { ((char*)p)[i]=v; return(v); }
int make_char (void) { return ((int)calloc(1,sizeof(char))); }
char char_ref (int p) { return (*(char*)p); }
char char_set (int p, char v) { *(char*)p=v; return(v); }

int make_inta (int n) { return ((int)calloc(n,sizeof(int))); }
int inta_ref (int p, int i) { return (((int*)p)[i]); }
int inta_set (int p, int i, int v) { ((int*)p)[i]=v; return(v); }
int make_int (void) { return ((int)calloc(1,sizeof(int))); }
int int_ref (int p) { return (*(int*)p); }
int int_set (int p, int v) { *(int*)p=v; return(v); }
