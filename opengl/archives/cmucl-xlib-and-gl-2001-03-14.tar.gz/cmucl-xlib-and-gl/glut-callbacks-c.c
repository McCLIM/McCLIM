
/* CMUCL GLUT callback glue: generated from glut-callbacks.lisp */
typedef unsigned int lispobj; /* safe assumtion? */
#define make_fixnum(n) ((lispobj)((n)<<2))
extern lispobj funcall0(lispobj function);
extern lispobj funcall1(lispobj function, lispobj arg0);
extern lispobj funcall2(lispobj function, lispobj arg0, lispobj arg1);
extern lispobj funcall3(lispobj function, lispobj arg0, lispobj arg1,
                        lispobj arg2);
/* funcall4 is not predefined, use call_into_lisp: */
extern lispobj call_into_lisp(lispobj fun, lispobj *args, int nargs);
lispobj funcall4(lispobj function, lispobj arg0, lispobj arg1,
                 lispobj arg2, lispobj arg3)
{
  static lispobj args[4];
  args[0] = arg0;
  args[1] = arg1;
  args[2] = arg2;
  args[3] = arg3;
  return call_into_lisp(function, args, 4);
}

#include <GL/glut.h>
/* GLUT/lisp callback code follows */
/*** glutDisplayFunc ***/
lispobj lisp_glutDisplayFunc = 0;
void glutDisplayFunc_callback(void) {
  funcall0(lisp_glutDisplayFunc);
}
void set_glutDisplayFunc_callback(lispobj function) {
  if (function==0 && lisp_glutDisplayFunc==0) return;
  if (function==0)
    glutDisplayFunc(0);
  else {
    lisp_glutDisplayFunc = function;
    glutDisplayFunc(glutDisplayFunc_callback);
  }
}
/*** glutReshapeFunc ***/
lispobj lisp_glutReshapeFunc = 0;
void glutReshapeFunc_callback(int arg0, int arg1) {
  funcall2(lisp_glutReshapeFunc, make_fixnum(arg0), make_fixnum(arg1));
}
void set_glutReshapeFunc_callback(lispobj function) {
  if (function==0 && lisp_glutReshapeFunc==0) return;
  if (function==0)
    glutReshapeFunc(0);
  else {
    lisp_glutReshapeFunc = function;
    glutReshapeFunc(glutReshapeFunc_callback);
  }
}
/*** glutKeyboardFunc ***/
lispobj lisp_glutKeyboardFunc = 0;
void glutKeyboardFunc_callback(unsigned char arg0, int arg1, int arg2) {
  funcall3(lisp_glutKeyboardFunc, make_fixnum((int)arg0), make_fixnum(arg1), make_fixnum(arg2));
}
void set_glutKeyboardFunc_callback(lispobj function) {
  if (function==0 && lisp_glutKeyboardFunc==0) return;
  if (function==0)
    glutKeyboardFunc(0);
  else {
    lisp_glutKeyboardFunc = function;
    glutKeyboardFunc(glutKeyboardFunc_callback);
  }
}
/*** glutMouseFunc ***/
lispobj lisp_glutMouseFunc = 0;
void glutMouseFunc_callback(int arg0, int arg1, int arg2, int arg3) {
  funcall4(lisp_glutMouseFunc, make_fixnum(arg0), make_fixnum(arg1), make_fixnum(arg2), make_fixnum(arg3));
}
void set_glutMouseFunc_callback(lispobj function) {
  if (function==0 && lisp_glutMouseFunc==0) return;
  if (function==0)
    glutMouseFunc(0);
  else {
    lisp_glutMouseFunc = function;
    glutMouseFunc(glutMouseFunc_callback);
  }
}
/*** glutMotionFunc ***/
lispobj lisp_glutMotionFunc = 0;
void glutMotionFunc_callback(int arg0, int arg1) {
  funcall2(lisp_glutMotionFunc, make_fixnum(arg0), make_fixnum(arg1));
}
void set_glutMotionFunc_callback(lispobj function) {
  if (function==0 && lisp_glutMotionFunc==0) return;
  if (function==0)
    glutMotionFunc(0);
  else {
    lisp_glutMotionFunc = function;
    glutMotionFunc(glutMotionFunc_callback);
  }
}
/*** glutPassiveMotionFunc ***/
lispobj lisp_glutPassiveMotionFunc = 0;
void glutPassiveMotionFunc_callback(int arg0, int arg1) {
  funcall2(lisp_glutPassiveMotionFunc, make_fixnum(arg0), make_fixnum(arg1));
}
void set_glutPassiveMotionFunc_callback(lispobj function) {
  if (function==0 && lisp_glutPassiveMotionFunc==0) return;
  if (function==0)
    glutPassiveMotionFunc(0);
  else {
    lisp_glutPassiveMotionFunc = function;
    glutPassiveMotionFunc(glutPassiveMotionFunc_callback);
  }
}
/*** glutEntryFunc ***/
lispobj lisp_glutEntryFunc = 0;
void glutEntryFunc_callback(int arg0) {
  funcall1(lisp_glutEntryFunc, make_fixnum(arg0));
}
void set_glutEntryFunc_callback(lispobj function) {
  if (function==0 && lisp_glutEntryFunc==0) return;
  if (function==0)
    glutEntryFunc(0);
  else {
    lisp_glutEntryFunc = function;
    glutEntryFunc(glutEntryFunc_callback);
  }
}
/*** glutVisibilityFunc ***/
lispobj lisp_glutVisibilityFunc = 0;
void glutVisibilityFunc_callback(int arg0) {
  funcall1(lisp_glutVisibilityFunc, make_fixnum(arg0));
}
void set_glutVisibilityFunc_callback(lispobj function) {
  if (function==0 && lisp_glutVisibilityFunc==0) return;
  if (function==0)
    glutVisibilityFunc(0);
  else {
    lisp_glutVisibilityFunc = function;
    glutVisibilityFunc(glutVisibilityFunc_callback);
  }
}
/*** glutIdleFunc ***/
lispobj lisp_glutIdleFunc = 0;
void glutIdleFunc_callback(void) {
  funcall0(lisp_glutIdleFunc);
}
void set_glutIdleFunc_callback(lispobj function) {
  if (function==0 && lisp_glutIdleFunc==0) return;
  if (function==0)
    glutIdleFunc(0);
  else {
    lisp_glutIdleFunc = function;
    glutIdleFunc(glutIdleFunc_callback);
  }
}
/*** glutMenuStateFunc ***/
lispobj lisp_glutMenuStateFunc = 0;
void glutMenuStateFunc_callback(int arg0) {
  funcall1(lisp_glutMenuStateFunc, make_fixnum(arg0));
}
void set_glutMenuStateFunc_callback(lispobj function) {
  if (function==0 && lisp_glutMenuStateFunc==0) return;
  if (function==0)
    glutMenuStateFunc(0);
  else {
    lisp_glutMenuStateFunc = function;
    glutMenuStateFunc(glutMenuStateFunc_callback);
  }
}
/*** glutSpecialFunc ***/
lispobj lisp_glutSpecialFunc = 0;
void glutSpecialFunc_callback(int arg0, int arg1, int arg2) {
  funcall3(lisp_glutSpecialFunc, make_fixnum(arg0), make_fixnum(arg1), make_fixnum(arg2));
}
void set_glutSpecialFunc_callback(lispobj function) {
  if (function==0 && lisp_glutSpecialFunc==0) return;
  if (function==0)
    glutSpecialFunc(0);
  else {
    lisp_glutSpecialFunc = function;
    glutSpecialFunc(glutSpecialFunc_callback);
  }
}
/*** glutSpaceballMotionFunc ***/
lispobj lisp_glutSpaceballMotionFunc = 0;
void glutSpaceballMotionFunc_callback(int arg0, int arg1, int arg2) {
  funcall3(lisp_glutSpaceballMotionFunc, make_fixnum(arg0), make_fixnum(arg1), make_fixnum(arg2));
}
void set_glutSpaceballMotionFunc_callback(lispobj function) {
  if (function==0 && lisp_glutSpaceballMotionFunc==0) return;
  if (function==0)
    glutSpaceballMotionFunc(0);
  else {
    lisp_glutSpaceballMotionFunc = function;
    glutSpaceballMotionFunc(glutSpaceballMotionFunc_callback);
  }
}
/*** glutSpaceballRotateFunc ***/
lispobj lisp_glutSpaceballRotateFunc = 0;
void glutSpaceballRotateFunc_callback(int arg0, int arg1, int arg2) {
  funcall3(lisp_glutSpaceballRotateFunc, make_fixnum(arg0), make_fixnum(arg1), make_fixnum(arg2));
}
void set_glutSpaceballRotateFunc_callback(lispobj function) {
  if (function==0 && lisp_glutSpaceballRotateFunc==0) return;
  if (function==0)
    glutSpaceballRotateFunc(0);
  else {
    lisp_glutSpaceballRotateFunc = function;
    glutSpaceballRotateFunc(glutSpaceballRotateFunc_callback);
  }
}
/*** glutSpaceballButtonFunc ***/
lispobj lisp_glutSpaceballButtonFunc = 0;
void glutSpaceballButtonFunc_callback(int arg0, int arg1) {
  funcall2(lisp_glutSpaceballButtonFunc, make_fixnum(arg0), make_fixnum(arg1));
}
void set_glutSpaceballButtonFunc_callback(lispobj function) {
  if (function==0 && lisp_glutSpaceballButtonFunc==0) return;
  if (function==0)
    glutSpaceballButtonFunc(0);
  else {
    lisp_glutSpaceballButtonFunc = function;
    glutSpaceballButtonFunc(glutSpaceballButtonFunc_callback);
  }
}
/*** glutButtonBoxFunc ***/
lispobj lisp_glutButtonBoxFunc = 0;
void glutButtonBoxFunc_callback(int arg0, int arg1) {
  funcall2(lisp_glutButtonBoxFunc, make_fixnum(arg0), make_fixnum(arg1));
}
void set_glutButtonBoxFunc_callback(lispobj function) {
  if (function==0 && lisp_glutButtonBoxFunc==0) return;
  if (function==0)
    glutButtonBoxFunc(0);
  else {
    lisp_glutButtonBoxFunc = function;
    glutButtonBoxFunc(glutButtonBoxFunc_callback);
  }
}
/*** glutDialsFunc ***/
lispobj lisp_glutDialsFunc = 0;
void glutDialsFunc_callback(int arg0, int arg1) {
  funcall2(lisp_glutDialsFunc, make_fixnum(arg0), make_fixnum(arg1));
}
void set_glutDialsFunc_callback(lispobj function) {
  if (function==0 && lisp_glutDialsFunc==0) return;
  if (function==0)
    glutDialsFunc(0);
  else {
    lisp_glutDialsFunc = function;
    glutDialsFunc(glutDialsFunc_callback);
  }
}
/*** glutTabletMotionFunc ***/
lispobj lisp_glutTabletMotionFunc = 0;
void glutTabletMotionFunc_callback(int arg0, int arg1) {
  funcall2(lisp_glutTabletMotionFunc, make_fixnum(arg0), make_fixnum(arg1));
}
void set_glutTabletMotionFunc_callback(lispobj function) {
  if (function==0 && lisp_glutTabletMotionFunc==0) return;
  if (function==0)
    glutTabletMotionFunc(0);
  else {
    lisp_glutTabletMotionFunc = function;
    glutTabletMotionFunc(glutTabletMotionFunc_callback);
  }
}
/*** glutTabletButtonFunc ***/
lispobj lisp_glutTabletButtonFunc = 0;
void glutTabletButtonFunc_callback(int arg0, int arg1, int arg2, int arg3) {
  funcall4(lisp_glutTabletButtonFunc, make_fixnum(arg0), make_fixnum(arg1), make_fixnum(arg2), make_fixnum(arg3));
}
void set_glutTabletButtonFunc_callback(lispobj function) {
  if (function==0 && lisp_glutTabletButtonFunc==0) return;
  if (function==0)
    glutTabletButtonFunc(0);
  else {
    lisp_glutTabletButtonFunc = function;
    glutTabletButtonFunc(glutTabletButtonFunc_callback);
  }
}
/*** glutMenuStatusFunc ***/
lispobj lisp_glutMenuStatusFunc = 0;
void glutMenuStatusFunc_callback(int arg0, int arg1, int arg2) {
  funcall3(lisp_glutMenuStatusFunc, make_fixnum(arg0), make_fixnum(arg1), make_fixnum(arg2));
}
void set_glutMenuStatusFunc_callback(lispobj function) {
  if (function==0 && lisp_glutMenuStatusFunc==0) return;
  if (function==0)
    glutMenuStatusFunc(0);
  else {
    lisp_glutMenuStatusFunc = function;
    glutMenuStatusFunc(glutMenuStatusFunc_callback);
  }
}
/*** glutOverlayDisplayFunc ***/
lispobj lisp_glutOverlayDisplayFunc = 0;
void glutOverlayDisplayFunc_callback(void) {
  funcall0(lisp_glutOverlayDisplayFunc);
}
void set_glutOverlayDisplayFunc_callback(lispobj function) {
  if (function==0 && lisp_glutOverlayDisplayFunc==0) return;
  if (function==0)
    glutOverlayDisplayFunc(0);
  else {
    lisp_glutOverlayDisplayFunc = function;
    glutOverlayDisplayFunc(glutOverlayDisplayFunc_callback);
  }
}
/*** glutWindowStatusFunc ***/
lispobj lisp_glutWindowStatusFunc = 0;
void glutWindowStatusFunc_callback(int arg0) {
  funcall1(lisp_glutWindowStatusFunc, make_fixnum(arg0));
}
void set_glutWindowStatusFunc_callback(lispobj function) {
  if (function==0 && lisp_glutWindowStatusFunc==0) return;
  if (function==0)
    glutWindowStatusFunc(0);
  else {
    lisp_glutWindowStatusFunc = function;
    glutWindowStatusFunc(glutWindowStatusFunc_callback);
  }
}
