
/* CMUCL GLUT callback glue: generated from glut-callbacks.lisp */
typedef unsigned int lispobj; /* safe assumtion? */
#define make_fixnum(n) ((lispobj)(((int)n)<<2))
extern lispobj funcall1(lispobj function, lispobj arg);

/* lisp variables */
lispobj *glut_parameters = 0;
lispobj call_glut_callback = 0;

#include <stdio.h>

void set_lisp_variables(lispobj params, lispobj func) {
  glut_parameters = (lispobj *)params;
  call_glut_callback = func;
}
/* debug printing */
void print_vars (void) {
  printf("Lisp vars: %d %d\n", (int)glut_parameters,
         (int)call_glut_callback);
  fflush(stdout);
}

#include <GL/glut.h>
/* GLUT/lisp callback code follows */
/*** glutDisplayFunc ***/
void glutDisplayFunc_callback (void) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutDisplayFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(0);
  funcall1(call_glut_callback, make_fixnum(0));
}
int glutDisplayFunc_check = 0;
void set_glutDisplayFunc_callback(int set) {
  if (set==0 && glutDisplayFunc_check==0)
    return;
  if (set==0)
    glutDisplayFunc(0);
  else {
    glutDisplayFunc_check = 1;
    glutDisplayFunc(glutDisplayFunc_callback);
  }
}
/*** glutReshapeFunc ***/
void glutReshapeFunc_callback (int arg0, int arg1) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutReshapeFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(2);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  funcall1(call_glut_callback, make_fixnum(1));
}
int glutReshapeFunc_check = 0;
void set_glutReshapeFunc_callback(int set) {
  if (set==0 && glutReshapeFunc_check==0)
    return;
  if (set==0)
    glutReshapeFunc(0);
  else {
    glutReshapeFunc_check = 1;
    glutReshapeFunc(glutReshapeFunc_callback);
  }
}
/*** glutKeyboardFunc ***/
void glutKeyboardFunc_callback (unsigned char arg0, int arg1, int arg2) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutKeyboardFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(3);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  glut_parameters[3] = make_fixnum(arg2);
  funcall1(call_glut_callback, make_fixnum(2));
}
int glutKeyboardFunc_check = 0;
void set_glutKeyboardFunc_callback(int set) {
  if (set==0 && glutKeyboardFunc_check==0)
    return;
  if (set==0)
    glutKeyboardFunc(0);
  else {
    glutKeyboardFunc_check = 1;
    glutKeyboardFunc(glutKeyboardFunc_callback);
  }
}
/*** glutMouseFunc ***/
void glutMouseFunc_callback (int arg0, int arg1, int arg2, int arg3) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutMouseFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(4);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  glut_parameters[3] = make_fixnum(arg2);
  glut_parameters[4] = make_fixnum(arg3);
  funcall1(call_glut_callback, make_fixnum(3));
}
int glutMouseFunc_check = 0;
void set_glutMouseFunc_callback(int set) {
  if (set==0 && glutMouseFunc_check==0)
    return;
  if (set==0)
    glutMouseFunc(0);
  else {
    glutMouseFunc_check = 1;
    glutMouseFunc(glutMouseFunc_callback);
  }
}
/*** glutMotionFunc ***/
void glutMotionFunc_callback (int arg0, int arg1) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutMotionFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(2);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  funcall1(call_glut_callback, make_fixnum(4));
}
int glutMotionFunc_check = 0;
void set_glutMotionFunc_callback(int set) {
  if (set==0 && glutMotionFunc_check==0)
    return;
  if (set==0)
    glutMotionFunc(0);
  else {
    glutMotionFunc_check = 1;
    glutMotionFunc(glutMotionFunc_callback);
  }
}
/*** glutPassiveMotionFunc ***/
void glutPassiveMotionFunc_callback (int arg0, int arg1) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutPassiveMotionFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(2);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  funcall1(call_glut_callback, make_fixnum(5));
}
int glutPassiveMotionFunc_check = 0;
void set_glutPassiveMotionFunc_callback(int set) {
  if (set==0 && glutPassiveMotionFunc_check==0)
    return;
  if (set==0)
    glutPassiveMotionFunc(0);
  else {
    glutPassiveMotionFunc_check = 1;
    glutPassiveMotionFunc(glutPassiveMotionFunc_callback);
  }
}
/*** glutEntryFunc ***/
void glutEntryFunc_callback (int arg0) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutEntryFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(1);
  glut_parameters[1] = make_fixnum(arg0);
  funcall1(call_glut_callback, make_fixnum(6));
}
int glutEntryFunc_check = 0;
void set_glutEntryFunc_callback(int set) {
  if (set==0 && glutEntryFunc_check==0)
    return;
  if (set==0)
    glutEntryFunc(0);
  else {
    glutEntryFunc_check = 1;
    glutEntryFunc(glutEntryFunc_callback);
  }
}
/*** glutVisibilityFunc ***/
void glutVisibilityFunc_callback (int arg0) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutVisibilityFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(1);
  glut_parameters[1] = make_fixnum(arg0);
  funcall1(call_glut_callback, make_fixnum(7));
}
int glutVisibilityFunc_check = 0;
void set_glutVisibilityFunc_callback(int set) {
  if (set==0 && glutVisibilityFunc_check==0)
    return;
  if (set==0)
    glutVisibilityFunc(0);
  else {
    glutVisibilityFunc_check = 1;
    glutVisibilityFunc(glutVisibilityFunc_callback);
  }
}
/*** glutIdleFunc ***/
void glutIdleFunc_callback (void) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutIdleFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(0);
  funcall1(call_glut_callback, make_fixnum(8));
}
int glutIdleFunc_check = 0;
void set_glutIdleFunc_callback(int set) {
  if (set==0 && glutIdleFunc_check==0)
    return;
  if (set==0)
    glutIdleFunc(0);
  else {
    glutIdleFunc_check = 1;
    glutIdleFunc(glutIdleFunc_callback);
  }
}
/*** glutMenuStateFunc ***/
void glutMenuStateFunc_callback (int arg0) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutMenuStateFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(1);
  glut_parameters[1] = make_fixnum(arg0);
  funcall1(call_glut_callback, make_fixnum(9));
}
int glutMenuStateFunc_check = 0;
void set_glutMenuStateFunc_callback(int set) {
  if (set==0 && glutMenuStateFunc_check==0)
    return;
  if (set==0)
    glutMenuStateFunc(0);
  else {
    glutMenuStateFunc_check = 1;
    glutMenuStateFunc(glutMenuStateFunc_callback);
  }
}
/*** glutSpecialFunc ***/
void glutSpecialFunc_callback (int arg0, int arg1, int arg2) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutSpecialFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(3);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  glut_parameters[3] = make_fixnum(arg2);
  funcall1(call_glut_callback, make_fixnum(10));
}
int glutSpecialFunc_check = 0;
void set_glutSpecialFunc_callback(int set) {
  if (set==0 && glutSpecialFunc_check==0)
    return;
  if (set==0)
    glutSpecialFunc(0);
  else {
    glutSpecialFunc_check = 1;
    glutSpecialFunc(glutSpecialFunc_callback);
  }
}
/*** glutSpaceballMotionFunc ***/
void glutSpaceballMotionFunc_callback (int arg0, int arg1, int arg2) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutSpaceballMotionFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(3);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  glut_parameters[3] = make_fixnum(arg2);
  funcall1(call_glut_callback, make_fixnum(11));
}
int glutSpaceballMotionFunc_check = 0;
void set_glutSpaceballMotionFunc_callback(int set) {
  if (set==0 && glutSpaceballMotionFunc_check==0)
    return;
  if (set==0)
    glutSpaceballMotionFunc(0);
  else {
    glutSpaceballMotionFunc_check = 1;
    glutSpaceballMotionFunc(glutSpaceballMotionFunc_callback);
  }
}
/*** glutSpaceballRotateFunc ***/
void glutSpaceballRotateFunc_callback (int arg0, int arg1, int arg2) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutSpaceballRotateFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(3);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  glut_parameters[3] = make_fixnum(arg2);
  funcall1(call_glut_callback, make_fixnum(12));
}
int glutSpaceballRotateFunc_check = 0;
void set_glutSpaceballRotateFunc_callback(int set) {
  if (set==0 && glutSpaceballRotateFunc_check==0)
    return;
  if (set==0)
    glutSpaceballRotateFunc(0);
  else {
    glutSpaceballRotateFunc_check = 1;
    glutSpaceballRotateFunc(glutSpaceballRotateFunc_callback);
  }
}
/*** glutSpaceballButtonFunc ***/
void glutSpaceballButtonFunc_callback (int arg0, int arg1) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutSpaceballButtonFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(2);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  funcall1(call_glut_callback, make_fixnum(13));
}
int glutSpaceballButtonFunc_check = 0;
void set_glutSpaceballButtonFunc_callback(int set) {
  if (set==0 && glutSpaceballButtonFunc_check==0)
    return;
  if (set==0)
    glutSpaceballButtonFunc(0);
  else {
    glutSpaceballButtonFunc_check = 1;
    glutSpaceballButtonFunc(glutSpaceballButtonFunc_callback);
  }
}
/*** glutButtonBoxFunc ***/
void glutButtonBoxFunc_callback (int arg0, int arg1) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutButtonBoxFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(2);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  funcall1(call_glut_callback, make_fixnum(14));
}
int glutButtonBoxFunc_check = 0;
void set_glutButtonBoxFunc_callback(int set) {
  if (set==0 && glutButtonBoxFunc_check==0)
    return;
  if (set==0)
    glutButtonBoxFunc(0);
  else {
    glutButtonBoxFunc_check = 1;
    glutButtonBoxFunc(glutButtonBoxFunc_callback);
  }
}
/*** glutDialsFunc ***/
void glutDialsFunc_callback (int arg0, int arg1) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutDialsFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(2);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  funcall1(call_glut_callback, make_fixnum(15));
}
int glutDialsFunc_check = 0;
void set_glutDialsFunc_callback(int set) {
  if (set==0 && glutDialsFunc_check==0)
    return;
  if (set==0)
    glutDialsFunc(0);
  else {
    glutDialsFunc_check = 1;
    glutDialsFunc(glutDialsFunc_callback);
  }
}
/*** glutTabletMotionFunc ***/
void glutTabletMotionFunc_callback (int arg0, int arg1) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutTabletMotionFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(2);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  funcall1(call_glut_callback, make_fixnum(16));
}
int glutTabletMotionFunc_check = 0;
void set_glutTabletMotionFunc_callback(int set) {
  if (set==0 && glutTabletMotionFunc_check==0)
    return;
  if (set==0)
    glutTabletMotionFunc(0);
  else {
    glutTabletMotionFunc_check = 1;
    glutTabletMotionFunc(glutTabletMotionFunc_callback);
  }
}
/*** glutTabletButtonFunc ***/
void glutTabletButtonFunc_callback (int arg0, int arg1, int arg2, int arg3) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutTabletButtonFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(4);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  glut_parameters[3] = make_fixnum(arg2);
  glut_parameters[4] = make_fixnum(arg3);
  funcall1(call_glut_callback, make_fixnum(17));
}
int glutTabletButtonFunc_check = 0;
void set_glutTabletButtonFunc_callback(int set) {
  if (set==0 && glutTabletButtonFunc_check==0)
    return;
  if (set==0)
    glutTabletButtonFunc(0);
  else {
    glutTabletButtonFunc_check = 1;
    glutTabletButtonFunc(glutTabletButtonFunc_callback);
  }
}
/*** glutMenuStatusFunc ***/
void glutMenuStatusFunc_callback (int arg0, int arg1, int arg2) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutMenuStatusFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(3);
  glut_parameters[1] = make_fixnum(arg0);
  glut_parameters[2] = make_fixnum(arg1);
  glut_parameters[3] = make_fixnum(arg2);
  funcall1(call_glut_callback, make_fixnum(18));
}
int glutMenuStatusFunc_check = 0;
void set_glutMenuStatusFunc_callback(int set) {
  if (set==0 && glutMenuStatusFunc_check==0)
    return;
  if (set==0)
    glutMenuStatusFunc(0);
  else {
    glutMenuStatusFunc_check = 1;
    glutMenuStatusFunc(glutMenuStatusFunc_callback);
  }
}
/*** glutOverlayDisplayFunc ***/
void glutOverlayDisplayFunc_callback (void) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutOverlayDisplayFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(0);
  funcall1(call_glut_callback, make_fixnum(19));
}
int glutOverlayDisplayFunc_check = 0;
void set_glutOverlayDisplayFunc_callback(int set) {
  if (set==0 && glutOverlayDisplayFunc_check==0)
    return;
  if (set==0)
    glutOverlayDisplayFunc(0);
  else {
    glutOverlayDisplayFunc_check = 1;
    glutOverlayDisplayFunc(glutOverlayDisplayFunc_callback);
  }
}
/*** glutWindowStatusFunc ***/
void glutWindowStatusFunc_callback (int arg0) {
  if ((glut_parameters == 0) || (call_glut_callback == 0)) {
    printf("glutWindowStatusFunc_callback: "
           "Lisp parameters or callback not initialized?\n"
           "%d %d\n",
           (int)glut_parameters, (int)call_glut_callback);
    fflush(stdout);
    return;
  }
  glut_parameters[0] = make_fixnum(1);
  glut_parameters[1] = make_fixnum(arg0);
  funcall1(call_glut_callback, make_fixnum(20));
}
int glutWindowStatusFunc_check = 0;
void set_glutWindowStatusFunc_callback(int set) {
  if (set==0 && glutWindowStatusFunc_check==0)
    return;
  if (set==0)
    glutWindowStatusFunc(0);
  else {
    glutWindowStatusFunc_check = 1;
    glutWindowStatusFunc(glutWindowStatusFunc_callback);
  }
}