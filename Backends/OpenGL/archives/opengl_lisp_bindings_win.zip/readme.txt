The OpenGL Lisp bindings allows users of Allegro CL 5.0 to make direct 
OpenGL graphics calls.

Original version by Richard Mann, 1996, 1998.
Updated to work with Windows by Mark Owen Riedl, 2001.

INSTALLATION:
------------

1. Copy the files opengl32.dll, glu32.dll, and glut32.dll into the 
   C:/WINDOWS/SYSTEM/ directory.

2. Modify the "load-system.lisp" file so that the *system-pathname* 
   matches your environment.

LOADING THE GL PACKAGE:
----------------------

1. In Allegro CL 5.0, load the file, "load-system.lisp".  This will
   load the bindings.dll and all required source files.  A new
   package called :GL will be created.

RUNNING THE EXAMPLE PROGRAM:
---------------------------

1. Load the GL package in Allegro CL 5.0 (see above).

2. Load the file, "test.lisp".

3. Type the following command into the Allegro CL 5.0 console:
   (main)

Note that the (glutmainloop) function is an endless loop.  The
function can be interrupted, but termination of the function or
the OpenGL graphics window will cause Allegro CL itself to close.
Debugging of routines, such as the (display) callback function can
be done by interrupting Allegro CL processing, entering debug mode,
and making the required changes.  If a new version of the callback
function is loaded into Allegro CL, it will be used once debug mode
is ended and Allegro CL resumes processing.

COMPILING bindings.dll:
----------------------

I have provided the DevStudio 6.0 workspace files.  These should be
sufficient to build bindings.dll.  The workspace is dependent on
opengl32.lib, glu32.lib, glut32.lib, and acl503.lib.  Make sure
the DevStudio environment knows the locations of these files on your
computer.  If you do not have them, I have provided them in lib.zip.